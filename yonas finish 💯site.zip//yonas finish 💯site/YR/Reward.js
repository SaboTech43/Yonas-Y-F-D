
        function createCounter() {
            let count = 0;
            return function () {
                count++;
                return count;
            }
        }
        const counter = createCounter();
        const button = document.getElementById("btn");
        const disp = document.getElementById("display");
        button.addEventListener("click", () => {
            disp.innerHTML = counter();
        });